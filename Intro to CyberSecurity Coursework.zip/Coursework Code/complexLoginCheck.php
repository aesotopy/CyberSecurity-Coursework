<?php
ini_set('session.cookie_samesite', 'Lax');
//header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");
include('CSRF.php');

//Record any failed login attempts and lock account if they do too many.
function failedAttemptCount($conn, $username)
{
    $maxAttempts = 5;       
    $lockDuration = 1 * 60; 

    //Check if the user already has failed attempts
    $checkQuery = "SELECT FailedAttempts FROM userLoginAttempts WHERE Username = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $failedAttempts = $row['FailedAttempts'] + 1;

        if ($failedAttempts >= $maxAttempts) {
            $lockedUntil = date("Y-m-d H:i:s", time() + $lockDuration);
            $updateQuery = "UPDATE userLoginAttempts SET FailedAttempts = ?, LockedUntil = ? WHERE Username = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("iss", $failedAttempts, $lockedUntil, $username);
            $stmt->execute();
            die("Too many failed login attempts. Your account is locked until " . $lockedUntil . ".");
        } else {
            $updateQuery = "UPDATE userLoginAttempts SET FailedAttempts = ? WHERE Username = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("is", $failedAttempts, $username);
            $stmt->execute();
        }
    } else {
        $insertQuery = "INSERT INTO userLoginAttempts (Username, FailedAttempts) VALUES (?, 1)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("s", $username);
        $stmt->execute();
    }
}


//Check if the CSRF token is present in the form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //check CSRF token is valid
    if (!isset($_POST['csrfToken']) || $_POST['csrfToken'] !== $_SESSION['csrfToken']) {
        die("Invalid CSRF token. Request could not be processed.");
    }

//reCAPTCHA for logging in
$url = 'https://www.google.com/recaptcha/api/siteverify';
$secret = '6LdmvIsqAAAAAImfo3wRnwJqTde8RNX8yZzGBMJ2';
$response = $_POST['token_generate'];
if (empty($response)) {
        die("reCAPTCHA token not received.");
}
$request = file_get_contents($url.'?secret='.$secret.'&response='.$response);
$result = json_decode($request, true);
	
if($result['success']){
	echo "<script>alert('Data save sucessful')</script>";
	//server and db connection
	$servername = "localhost";
	$rootUser = "root";
	$db = "SocNet";
	$rootPassword = "";

	//create connection
	$conn = new mysqli($servername, $rootUser, $rootPassword, $db);

	//check connection
	if($conn -> connect_error){
		die("Connection failed" .$conn -> connect_error);
	}

	//copy user data from form 
	$username = htmlspecialchars($_POST['txtUsername']);
	$password = htmlspecialchars($_POST['txtPassword']);
	$hashedPassword = password_hash($password,PASSWORD_DEFAULT);

	// Check if the user is locked
	$checkLockQuery = "SELECT FailedAttempts, LockedUntil FROM userLoginAttempts WHERE Username = ?";
	$stmt = $conn->prepare($checkLockQuery);
	$stmt->bind_param("s", $username);
	$stmt->execute();
	$result = $stmt->get_result();
	$row = $result->fetch_assoc();

	if ($row) {
		$failedAttempts = $row['FailedAttempts'];
		$lockedUntil = $row['LockedUntil'];

		if ($lockedUntil && strtotime($lockedUntil) > time()) {
			die("Account locked. Try again after " . date("H:i:s", strtotime($lockedUntil)) . ".");
		}
	}

	$userQuery = "SELECT * FROM SystemUser WHERE Username = ?";
	$stmt = $conn->prepare($userQuery);
	$stmt->bind_param("s", $username);
	$stmt->execute();
	$result = $stmt->get_result();

	//flag variable
	$userFound = 0;

	if ($result->num_rows > 0) {
		while ($userRow = $result->fetch_assoc()) {
			if (password_verify($password, $userRow['Password'])) {
				$userFound = true;
				$role = $userRow['Role']; // Fetch the role column

				// Redirect the users based on thier roles
				if ($role === 'admin') {
					echo "Welcome Admin " .htmlspecialchars($username, ENT_QUOTES, 'UTF-8'). "!";
					echo "<br/> Redirecting you to the admin dashboard...";
					header("Location: adminDashboard.php");
					// Reset failed attempts on successful login
					$resetAttemptsQuery = "DELETE FROM userLoginAttempts WHERE Username = ?";
					$stmt = $conn->prepare($resetAttemptsQuery);
					$stmt->bind_param("s", $username);
					$stmt->execute();
					exit();
				} else {
					echo "Hi " .htmlspecialchars($username, ENT_QUOTES, 'UTF-8'). "!";
					echo "<br/> Welcome to our website.";
					echo "<br/><br/> Click <a href='requestEvaluation.php'>here!</a> if you would like to request an evaluation.";
					// Reset failed attempts on successful login
					$resetAttemptsQuery = "DELETE FROM userLoginAttempts WHERE Username = ?";
					$stmt = $conn->prepare($resetAttemptsQuery);
					$stmt->bind_param("s", $username);
					$stmt->execute();
					exit();
				}
			} else {
				failedAttemptCount($conn, $username);
				echo "Wrong password.";
				exit();
			 }
		}
	} 

	if (!$userFound) {
		failedAttemptCount($conn, $username);
		echo "This user was not found in our database.";
	}

	$stmt->close();
	$conn->close();
	//After processing the form deal with csrf token
	unset($_SESSION['csrfToken']);

}else{
	 die("<script>alert('Data not saved')</script>");
 }
}

?>