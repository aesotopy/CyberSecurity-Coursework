<?php
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");

include('staticKey.php');

define("CIPHER", "aes-256-cbc");

$iv_size = openssl_cipher_iv_length(CIPHER);

// Use the static encryption key from my external file
define("ENCRYPTION_KEY", ENCRYPTED_KEY);

// Encrypt Function
function encryptEmail($email) {
    // Generate a random IV for each encryption
    $iv = openssl_random_pseudo_bytes($GLOBALS['iv_size']);
    
    // Encrypt the email using the defined cipher, key, and IV
    $encryptedEmail = openssl_encrypt($email, CIPHER, ENCRYPTION_KEY, 0, $iv);
    
    return base64_encode($iv . $encryptedEmail);
}

// Decrypt Function
function decryptEmail($encryptedEmailWithIV) {
    // Decode the base64-encoded encrypted email
    $data = base64_decode($encryptedEmailWithIV);
    
    $iv = substr($data, 0, $GLOBALS['iv_size']);
    
    $encryptedEmail = substr($data, $GLOBALS['iv_size']);
    
    // Decrypt the email using the IV and encryption key
    return openssl_decrypt($encryptedEmail, CIPHER, ENCRYPTION_KEY, 0, $iv);
}
?>



