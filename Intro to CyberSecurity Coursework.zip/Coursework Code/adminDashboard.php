<?php
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");

echo "<h1>Welcome to the Admin Dashboard!</h1>";
echo "<br/><br/>To manage customer sent in evaluations Click <a href='adminViewEvaluations.php'>HERE</a>";

?>
