<?php
//header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self' https://cdn.typingdna.com; style-src 'self';");
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to My Site</title>
    
</head>
<body>
    <h1>Welcome to Lovejoy's Antique Evaluation Website</h1>
    <p>Please <a href="complexLoginForm.php">login</a> to access your account.</p>

</body>
</html>


