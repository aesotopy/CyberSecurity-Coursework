<?php
ini_set('session.cookie_samesite', 'Lax');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");
include('CSRF.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrfToken']) || $_POST['csrfToken'] !== $_SESSION['csrfToken']) {
        die("Invalid CSRF token. Request could not be processed.");
    }

$servername = "localhost";
$rootUser = "root";
$db = "SocNet";
$rootPassword = "";

$conn = new mysqli($servername, $rootUser, $rootPassword, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the token and new password
$token = $_POST['token'];
$password = $_POST['password'];
$confirmPassword = $_POST['confirmPassword'];

// Validate passwords
if ($password !== $confirmPassword) {
    die("Passwords do not match.");
}

// Validate the token
$stmt = $conn->prepare("SELECT Email, ResetTokenExpiry FROM SystemUser WHERE ResetToken = ?");
$stmt->bind_param("s", $token);
$stmt->execute();
$stmt->store_result(); 

$stmt->bind_result($email, $expiry);
if ($stmt->fetch()) {
    if (time() > $expiry) {
        die("Reset token has expired.");
    }

    // Update the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $updateStmt = $conn->prepare("UPDATE SystemUser SET Password = ?, ResetToken = NULL, ResetTokenExpiry = NULL WHERE Email = ?");
    $updateStmt->bind_param("ss", $hashedPassword, $email);
    if ($updateStmt->execute()) {
        echo "Password has been updated successfully.";
		echo "<br/><br/> Click <a href='complexLoginForm.php'>here!</a> if you would like to now login.";
    } else {
        echo "Error: " . $updateStmt->error;
    }
    $updateStmt->close();
} else {
    echo "Invalid reset token.";
}

$stmt->close();
$conn->close();
}
unset($_SESSION['csrfToken']);

?>
