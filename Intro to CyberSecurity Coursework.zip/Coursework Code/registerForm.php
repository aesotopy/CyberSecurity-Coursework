<?php
ini_set('session.cookie_samesite', 'Lax');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self';");
include('CSRF.php');

echo "<form action='registerFormCheck.php' method='POST'>";
echo "<input type='hidden' name='csrfToken' value='" . htmlspecialchars($_SESSION['csrfToken']) . "'>";
echo "<h1> Please register your details below: </h1>";
echo "<pre>";
echo "Type in your Forename";
echo "<input name='txtForename' type='text' />";

echo "<br/>Type in your Surname";
echo "<input name='txtSurname' type='text' />";

echo "<br/>Type in your Username";
echo "<input name='txtUsername' type='text' />";

echo "<br/>Type in your Email Address";
echo "<input name='txtEmailOne' type='text' />";
echo "<br/>Type your Email Address again";
echo "<input name='txtEmailTwo' type='text' />";

echo "<br/>Type in your Telephone Number";
echo "<input name='txtTelephone' type='text' />";

echo "<br/>Type in your password";
echo "<input name='txtPasswordOne' type='password' oninput='checkPasswordStrength(this.value)' />";
echo "<span id='passwordStrength'> </span>";
echo "<br/>Type your password again";
echo "<input name='txtPasswordTwo' type='password' />";
echo "<br/><br/>Please give an answer for the following security questions. 
These will be used to recover your password if you have forgotten it.";
echo "<br/>What was the name of your first pet?";
echo "<input name='txtSecQuest1' type='password' />";
echo "<br/>What is your favourite fruit?";
echo "<input name='txtSecQuest2' type='password' />";
echo "</pre>";

echo "<br/> <input type='submit' value='Register'>";
echo "</form>";

?>

<script>

function checkPasswordStrength(password) {
    let strength = "Weak";
    let recommendations = [];

    if (password.length >= 8) {
        strength = "Moderate";
        recommendations = ["Try adding some numbers and make sure to use both upper and lower case characters to improve password strength."];
    }
    if (/[A-Z]/.test(password) && /[a-z]/.test(password) && /[0-9]/.test(password)) {
        strength = "Strong";
        recommendations = ["Try adding some special characters to improve password strength."];
    }
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        strength = "Very Strong";
        recommendations = ["Your password is now very strong!"];
    }

    // Display the strength and recommendations
    document.getElementById("passwordStrength").innerHTML = `<strong>${strength}</strong>: ${recommendations.join(" ")}`;
}

</script>