<?php
ini_set('session.cookie_samesite', 'Lax');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");
include('CSRF.php');
include('encryptEmail.php'); 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrfToken']) || $_POST['csrfToken'] !== $_SESSION['csrfToken']) {
        die("Invalid CSRF token. Request could not be processed.");
    }
	
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "SocNet";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//Get the inputs from the user
$secquestone = htmlspecialchars($_POST['txtSecQuest1']);
$secquesttwo = htmlspecialchars($_POST['txtSecQuest2']);
$email = htmlspecialchars($_POST['txtEmail']); 

//Query to fetch the user details
$sql = "SELECT * FROM SystemUser WHERE Email IS NOT NULL";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

$userFound = false; 

while ($user = $result->fetch_assoc()) {
    // Decrypt the stored email
    $decryptedEmail = @decryptEmail($user['Email']);

    // Check if the email entered by the user matches the decrypted email
    if ($email == $decryptedEmail) {
        $userFound = true;

        // Verify the security questions
        if (password_verify($secquestone, $user['SecurityQuestion1']) && password_verify($secquesttwo, $user['SecurityQuestion2'])) {
            // Generate a reset token
            $resetToken = bin2hex(random_bytes(16)); 
            $resetTokenExpiry = time() + (60 * 5); 

            // Save the reset token and its expiry in the database
            $updateSql = "UPDATE SystemUser SET ResetToken = ?, ResetTokenExpiry = ? WHERE Email = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param("sis", $resetToken, $resetTokenExpiry, $user['Email']);
            $updateStmt->execute();

            // Generate the reset link
            $resetLink = "http://localhost/Compsec/Labs/Coursework/resetPassword.php?token=" . $resetToken;

            // Display the reset link to the user
            echo "Your reset link: <a href='$resetLink'>$resetLink</a>";
            break; 
        } else {
            echo "Security question answers are incorrect.";
            break;
        }
    }
}

if (!$userFound) {
    echo "User not found. Ensure the email exists in the database.";
}

$stmt->close();
$conn->close();
}
unset($_SESSION['csrfToken']);

?>
