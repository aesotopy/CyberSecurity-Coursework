<?php
// Generate a static key 
$staticKey = openssl_random_pseudo_bytes(32); 
echo bin2hex($staticKey); 

?>