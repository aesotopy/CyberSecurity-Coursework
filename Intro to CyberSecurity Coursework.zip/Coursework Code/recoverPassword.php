<?php
ini_set('session.cookie_samesite', 'Lax');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");
include('CSRF.php');

echo "<form action='recoverPasswordCheck.php' method='POST'>";
echo "<input type='hidden' name='csrfToken' value='" . htmlspecialchars($_SESSION['csrfToken']) . "'>";
echo "Please enter the email address you signed up with if you would like to recieve a reset password link.";
echo "<br/><br/>For Email recoverery, enter your email address below:";
echo "<input name='txtEmail' type='text' />";

echo "<br/><br/>And enter the answers to your security questions that you provided when you first registered an account:";
echo "<br/><br/>What was the name of your first pet?";
echo "<input name='txtSecQuest1' type='password' />";
echo "<br/>What is your favourite fruit?";
echo "<input name='txtSecQuest2' type='password' />";

echo "<br/> <input type='submit' value='Submit' />";
echo "</form>";

?>