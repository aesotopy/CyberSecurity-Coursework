<?php
ini_set('session.cookie_samesite', 'Lax');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");
include('CSRF.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrfToken']) || $_POST['csrfToken'] !== $_SESSION['csrfToken']) {
        die("Invalid CSRF token. Request could not be processed.");
    }

$targetDir='objectPhotos/';
$targetFile=$targetDir . basename($_FILES['fileToUpload']['name']);
$validUpload=1;
$imageFileType=strtolower(pathinfo($targetFile,PATHINFO_EXTENSION));

//check if the file being uploaded is an actual img
if(isset($_POST['submit'])){
	$check=getimagesize($_FILES['fileToUpload']['tempName']);
	if($check !== false){
		echo "Your file has been successfully uploaded -" .$check['mime'];
		$validUpload=1;
	}else{
		echo "Error your file is not a valid image.";
		$validUpload=0;
	 }
}
// Check if $uploadOk is set to 0 by an error
if ($validUpload == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFile)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}
}
unset($_SESSION['csrfToken']);

?>