<?php
ini_set('session.cookie_samesite', 'Lax');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");
include('CSRF.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrfToken']) || $_POST['csrfToken'] !== $_SESSION['csrfToken']) {
        die("Invalid CSRF token. Request could not be processed.");
    }

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "SocNet"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the form data
$comments = htmlspecialchars($_POST['txtUserComments']);
$contactMethod = $_POST['txtContactMethod'] ?? '';
$file = $_FILES['fileToUpload'];

// Validate the uploaded file
$targetDir = 'objectPhotos/'; 
$targetFile = $targetDir . basename($file['name']);
$imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
$allowedTypes = ["jpg", "jpeg", "png", "gif"];

if (!in_array($imageFileType, $allowedTypes)) {
    die("Only JPG, JPEG, PNG, and GIF files are allowed.");
}

if (!move_uploaded_file($file["tmp_name"], $targetFile)) {
    die("Sorry, there was an error uploading your file.");
}

if (empty($contactMethod) || ($contactMethod !== 'Phone Number' && $contactMethod !== 'Email Address')) {
    die("Please select a valid contact method.");
}


// Insert the data into the database
$sql = "INSERT INTO UserEvaluation (Comments, ContactMethod, ImagePath) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $comments, $contactMethod, $targetFile);

if ($stmt->execute()) {
    echo "Your evaluation has been submitted successfully.";
	echo "<br/><br/> Click <a href='complexLoginForm.php'>here!</a> if you would like to return to the login form.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
}
unset($_SESSION['csrfToken']);

?>
