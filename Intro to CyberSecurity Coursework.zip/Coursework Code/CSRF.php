<?php
// Start the session
session_start();

// Generate a CSRF token if it doesn't exist
if (empty($_SESSION['csrfToken'])) {
    $_SESSION['csrfToken'] = bin2hex(random_bytes(32)); // Create a unique CSRF token
}
?>
