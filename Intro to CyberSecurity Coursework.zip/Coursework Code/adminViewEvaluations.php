<?php
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "SocNet";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM UserEvaluation ORDER BY SubmittedAt DESC";
$result = $conn->query($sql);

echo "<h1>User Evaluations</h1>";
echo "<table border='1'>
<tr>
    <th>ID</th>
    <th>Comments</th>
    <th>Contact Method</th>
    <th>Image</th>
    <th>Submitted At</th>
</tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['userID']}</td>
        <td>{$row['Comments']}</td>
        <td>{$row['ContactMethod']}</td>
        <td><img src='{$row['ImagePath']}' alt='Image' width='100'></td>
        <td>{$row['SubmittedAt']}</td>
    </tr>";
}

echo "</table>";

$conn->close();

?>
