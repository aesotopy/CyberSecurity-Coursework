<?php
ini_set('session.cookie_samesite', 'Lax');
//header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self';");
include('CSRF.php');


echo "<form action='complexLoginCheck.php' method='POST'>";
echo "<input type='hidden' name='csrfToken' value='" . htmlspecialchars($_SESSION['csrfToken']) . "'>";
echo "username";
echo "<input name='txtUsername' type='text' />";
echo "<br/> Password";
echo "<input name='txtPassword' type='password' />";
echo "<br/> <input type='submit' name='submit' value='Login'>";
echo "<input type='hidden' name='token_generate' id='token_generate'>";
echo "<br /><br />Not Registered Yet? Click <a href='registerForm.php'>HERE</a>";
echo "<br/><br/>Forgotten Your Password? Click <a href='recoverPassword.php'>HERE</a>";
echo "</form>"; 

?>

<script src="https://www.google.com/recaptcha/api.js?render=6LdmvIsqAAAAAMp1kA8AUFXVXqT11K42H5q_-wAp"></script>
    
<script>
   
grecaptcha.ready(function() {
grecaptcha.execute('6LdmvIsqAAAAAMp1kA8AUFXVXqT11K42H5q_-wAp', {action: 'submit'}).then(function(token) {
var response = document.getElementById('token_generate');
response.value = token;
});
});
   
</script>