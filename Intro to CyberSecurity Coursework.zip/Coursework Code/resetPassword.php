<?php
ini_set('session.cookie_samesite', 'Lax');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self';");
include('CSRF.php');

$token = $_GET['token'] ?? '';
if (empty($token)) {
    die("Invalid reset link.");
}

echo "<form action='updatePassword.php' method='POST'>";
echo "<input type='hidden' name='csrfToken' value='" . htmlspecialchars($_SESSION['csrfToken']) . "'>";
echo "<input type='hidden' name='token' value='" . htmlspecialchars($token) . "'>"; 
echo "<label for='password'>Enter new password:</label>";
echo "<input type='password' id='password' name='password' oninput='checkPasswordStrength(this.value)' required/>";
echo "<br/><br/><span id='passwordStrength'> </span>";
echo "<br/><br/>";
echo "<label for='confirmPassword'>Confirm new password:</label>";
echo "<input type='password' id='confirmPassword' name='confirmPassword' required>";
echo "<button type='submit'>Reset Password</button>";
echo "</form>";

?>
<script>

function checkPasswordStrength(password) {
    let strength = "Weak";
    let recommendations = [];

    if (password.length >= 8) {
        strength = "Moderate";
        recommendations = ["Try adding some numbers and make sure to use both upper and lower case characters to improve password strength."];
    }
    if (/[A-Z]/.test(password) && /[a-z]/.test(password) && /[0-9]/.test(password)) {
        strength = "Strong";
        recommendations = ["Try adding some special characters to improve password strength."];
    }
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        strength = "Very Strong";
        recommendations = ["Your password is now very strong!"];
    }

    // Display the strength and recommendations
    document.getElementById("passwordStrength").innerHTML = `<strong>${strength}</strong>: ${recommendations.join(" ")}`;
}

</script>