<?php
ini_set('session.cookie_samesite', 'Lax');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");
include('CSRF.php');

echo "<form action='userEvaluationCheck.php' method='POST' enctype='multipart/form-data'>";
echo "<input type='hidden' name='csrfToken' value='" . htmlspecialchars($_SESSION['csrfToken']) . "'>";
echo"<table>";

echo"<tr>";
echo"<td>";
echo"</td>";
echo"<td>";
echo "Hello and Welcome Customer!";
echo"</td>";
echo"</tr>";

echo"<tr>";
echo"<td>";
echo"</td>";
echo"<td>";
echo "Please enter the details of your object and request in the box below:";
echo"</td>";
echo"</tr>";

echo"<tr>";
echo"<td>";
echo"</td>";
echo"<td>";
echo"<textarea name='txtUserComments' cols='35' rows='6'>";
echo"</textarea>";
echo"</td>";
echo"</tr>";

echo"<tr>";
echo"<td>";
echo"</td>";
echo"<td>";
echo "Please select your prefered method of contact below:";
echo"</td>";
echo"</tr>";

echo"<tr>";
echo"<td>";
echo"</td>";
echo"<td>";
echo"<select name='txtContactMethod' required>"; 
echo "<option value='' disabled selected>Select</option>";
echo  "<option value='Phone Number'>Phone Number</option>";
echo  "<option value='Email Address'>Email Address</option>";  
echo"</select>"; 
echo"</td>";
echo"</tr>"; 

echo"<tr>";
echo"<td>";
echo"</td>";
echo"<td>";
echo"<form action='fileUpload.php' method='POST' enctype='multipart/form-data'>";
echo"<br/>Select the image you wish to upload:";
echo"<input type='file' name='fileToUpload' id='fileToUpload' required>";
echo"<input type='submit' value='Submit Evaluation' name='Submit'>";
echo"</form>";
echo"</td>";
echo"</tr>";

echo"</table>";

?>