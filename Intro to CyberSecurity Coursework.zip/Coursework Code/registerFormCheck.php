<?php
ini_set('session.cookie_samesite', 'Lax');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self';");
include('CSRF.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrfToken']) || $_POST['csrfToken'] !== $_SESSION['csrfToken']) {
        die("Invalid CSRF token. Request could not be processed.");
    }
	
$mysql_host="localhost";
$mysql_database="SocNet";
$mysql_user="root";
$mysql_password="";

//connect to the server
$connection = mysqli_connect($mysql_host, $mysql_user, $mysql_password, $mysql_database) or die ("could not connect to the server");

//copy all user data from the form into variables
$forename=htmlspecialchars($_POST['txtForename']);
$surname=htmlspecialchars($_POST['txtSurname']);
$username=htmlspecialchars($_POST['txtUsername']);
$emailone=htmlspecialchars($_POST['txtEmailOne']);
$emailtwo=htmlspecialchars($_POST['txtEmailTwo']);
$telephone=htmlspecialchars($_POST['txtTelephone']);
$passwordone=htmlspecialchars($_POST['txtPasswordOne']);
$passwordtwo=htmlspecialchars($_POST['txtPasswordTwo']);
$secquestone=htmlspecialchars($_POST['txtSecQuest1']);
$secquesttwo=htmlspecialchars($_POST['txtSecQuest2']);

//hash password
$hashedPassword = password_hash($passwordone, PASSWORD_DEFAULT);

//encrypt email
include('encryptEmail.php');
$encryptedEmail = encryptEmail($emailone);

//hash both security question answers
$hashedSQ1 = password_hash($secquestone, PASSWORD_DEFAULT);
$hashedSQ2 = password_hash($secquesttwo, PASSWORD_DEFAULT);

//create a variable to indicate if an error has occored or not, 0=false and 1=true
$errorOccurred = 0;

//make sure that all text boxes were not blank
if($forename == ""){
	echo "Forename was blank!<br/>";
	$errorOccurred = 1;
}
if($surname == ""){
	echo "Surname was blank!<br/>";
	$errorOccurred = 1;
}
if($username == ""){
	echo "Username was blank!<br/>";
	$errorOccurred = 1;
}
if($emailone == "" OR $emailtwo == ""){
	echo "Email not provided!<br/>";
	$errorOccurred = 1;
}
if($passwordone == "" OR $passwordtwo == ""){
	echo "Password empty, check it.<br/>";
	$errorOccurred = 1;
}
if($secquestone == "" OR $secquesttwo == ""){
	echo "Security question/s unanswered.<br/>";
	$errorOccurred = 1;
}
//check if username already exists in the database
$userResult = $connection -> query("SELECT * FROM SystemUser");

while($userRow = mysqli_fetch_array($userResult)){
	//check to see if the current user username matches the one from the user
	if($userRow['Username'] == $username){
		echo "The username has already been used!<br/>";
		$errorOccurred = 1;
	}
}

//check to see if the email address is registered
$userResult = $connection -> query("SELECT * FROM SystemUser");

while($userRow = mysqli_fetch_array($userResult)){
	//check to see if the email entered matches with any value in the database
	if($userRow['Email'] == $emailone){
		echo "This email address has already been used.<br/>";
		$errorOccurred = 1;
	}
}

//check to make sure email address contains @
if(strpos($emailone, "@") == false OR strpos($emailtwo, "@") == false){
	echo "The email address are not valid.<br/>";
	//$errorOccurred = 1;
}

//check to make sure emails match
if($emailone != $emailtwo){
	echo "Emails do not match!<br/>";
	$errorOccurred = 1;
}

//check to make sure that passwords match
if($passwordone != $passwordtwo){
	echo "The passwords are different.<br/>";
	$errorOccurred = 1;
}

//check to see if an error has occurred, then add the details to the database
if($errorOccurred == 0){
	$sql = "INSERT INTO SystemUser (Username, Password, Forename, Surname, Email, Telephone, SecurityQuestion1, SecurityQuestion2)
			VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
	$stmt = $connection -> prepare($sql);
	$stmt -> bind_param("ssssssss", $username, $hashedPassword, $forename, $surname, $encryptedEmail, $telephone, $hashedSQ1, $hashedSQ2);
	if($stmt -> execute() === TRUE){
		echo "Hello " .htmlspecialchars($forename, ENT_QUOTES, 'UTF-8'). " " .htmlspecialchars($surname, ENT_QUOTES, 'UTF-8') ."<br/>";
		echo "Thank you for joining the computing security network";
		echo "<br/><br/> Click <a href='complexLoginForm.php'>here!</a> if you would like to now login.";
	}
	else{
		echo "Error: " . $stmt -> error;
	}
	$stmt -> close();
}
}
unset($_SESSION['csrfToken']);

?>
